######################################################
# DISCLAIMER: This test fails for certain combinations of fit_values_alpha and fit_values_train_calib_size,
# as there might be to little observations to compute the 1 - alpha quantile on the calibration set.
# This is however due to the use of the Iris dataset, which is quite small.
######################################################



import pytest
import itertools
from iml.methods.conformal_pred import Conformal_Prediction
from datasets.datasets import SpanishData, GLADdata, CRdata, ConsultingData
import matplotlib
from sklearn.datasets import load_iris
from typing import Optional
from sklearn.model_selection import train_test_split
from sklearn.datasets import fetch_openml

# Test Conformal Prediction
# Execute via: python -m pytest iml/tests/conformal_pred.py

class IrisData(ConsultingData):
    def __init__(self):
        self.X, self.y = load_iris(return_X_y=True)
        self.y_classes = 3
    
    def load(self,
             split: bool= True,
             n_train: int= 80,
             n_test: int= 50,
             standardize_features_bool: bool= False,
             to_torch_tensor: bool= False,
             device: str= "cpu"):
        X_train, X_test, y_train, y_test = train_test_split(self.X, self.y, test_size=n_test, random_state=42)
        return X_train, X_test, y_train, y_test
    

class MNISTData(ConsultingData):
    def __init__(self):
        mnist = fetch_openml('mnist_784', version=1)
        self.X, self.y = mnist.data.sample(n=1000).sample(n=80, axis=1), mnist.target.sample(n=1000)

        self.y_classes = 10
    
    def load(self,
             split: bool= True,
             n_train: Optional[int]= None,
             n_test: Optional[int]= None,
             standardize_features_bool: bool= False,
             to_torch_tensor: bool= False,
             device: str= "cpu"):
        X_train, X_test, y_train, y_test = train_test_split(self.X, self.y, test_size=n_test, random_state=42)
        return X_train, X_test, y_train, y_test

# Define ranges for each parameter
# Init-function  parameters
init_values_data = [MNISTData(), IrisData()]
init_values_debug = [True]

# Fit-function parameters
fit_values_alpha = [0.9, 0.95, 0.99]
fit_values_cv = ["prefit"]
fit_values_method = ["score", "cumulated_score", "raps", "top_k"]
fit_values_train_calib_size = [0.5, 0.8]

# Plot-function parameters
plot_values_alphas = [[0.1, 0.05]]
plot_values_x_axis = [0, 1, 2, 3]
plot_values_y_axis = [0, 1, 2, 3]
plot_values_point_size = [20, 30, 40]
plot_values_opacity_and_size: bool = [True, False] 
            
# Avoid pop-up windows for plots
matplotlib.use('Agg')

# Use itertools to generate all combinations of parameters
configurations = list(itertools.product(init_values_data,
                                        init_values_debug,
                                        fit_values_alpha,
                                        fit_values_cv,
                                        fit_values_method,
                                        fit_values_train_calib_size,
                                        plot_values_alphas,
                                        plot_values_x_axis,
                                        plot_values_y_axis, 
                                        plot_values_point_size,
                                        plot_values_opacity_and_size))

# Test Function
@pytest.mark.parametrize('config', configurations)
def test_your_function(config):
    try:
        temp_cf = Conformal_Prediction(data=config[0], n_train=80, n_test=50,
                                    debug=config[1])

        temp_cf.fit(alpha=config[2],
                    cv=config[3],
                    method= config[4],
                    train_calib_size=config[5])

        temp_cf.get_conformal_prediction()

        temp_cf.plot(alphas=config[6],
                     x_axis=config[7],
                     y_axis=config[8],
                     point_size=config[9],
                     opacity_and_size=config[10])


    except Exception as e:
        pytest.fail(
            f"Your function raised an exception with config {config}: {str(e)}")

