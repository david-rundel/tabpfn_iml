from tabpfniml import dataset_iml

class SpanishData(dataset_iml):
    """
    The following is taken from https://doi.org/10.1007/s00586-022-07188-w.
    More information about the dataset can be found in the publication by Liew et al. (2022)

    Forty-seven health care centres were selected by the Spanish Back Pain Research Network to be invited to participate
    in this study, based on their past involvement in research on neck and low back pain. The centres were located across
    11 out of the 17 Administrative regions in the country (Andalucía, Aragón, Asturias, Baleares, Castilla-León, Cataluña,
    Extremadura, Galicia, Madrid, Murcia, Vascongadas). Fifteen centres belonged to the Spanish National Health Service (SNHS),
    six to not-for-profit institutions working for the SNHS, and 26 were private. They included eight primary care centres,
    18 physical therapy practices, and 21 specialty Services (five in rheumatology, six in rehabilitation, four in
    neuroreflexotherapy (NRT), and six in orthopaedic surgery). Participant recruitment spanned the period of March 2014 to
    February 2017. Three dichotomous outcomes of a clinically meaningful improvement in neck pain, arm pain, and disability at
    3 months follow-up were used.


    """ 
    def __init__(self,
                 id: int= 1,
                 use_ohe=False):
        """
        Initializes SpanishData by setting some specific attributes and calling the parent-classes __init__().

        Args:
            id (int, optional): The identifier of the sheet/file in the dataset to initialize. Defaults to 1.
        """
        self.dataset_name = "Spanish dataset"
        self.id= id
        self.path= "consulting_datasets/datasets_spanish"
        if use_ohe:
            self.id_to_file = {1: "spanish_imp_neckpain_ohe.csv",
                                2:  "spanish_imp_armpain_ohe.csv", 
                                3:  "spanish_imp_disability_ohe.csv"}
        else:
            self.id_to_file = {1: "spanish_imp_neckpain.csv",
                                2: "spanish_imp_armpain.csv", 
                                3: "spanish_imp_disability.csv"}
        self.id_to_target_name = {1: "neck pain improved", 
                                  2: "arm pain improved", 
                                  3: "disability improved"}
        self.feature_complete_names = {}

        if use_ohe:
            self.categorical_features = ['sex', 'employ_status_0', 'employ_status_2', 'employ_status_2', 
                                         'time_first_episod_cat_0', 'time_first_episod_cat_1', 'time_first_episod_cat_2', 'chronicity',
                                        'time_first_episod_cat_3', 'diagn_RX', 'diagn_MRI', 'disc_degenerat', 'facet_joint_deg',
                                        'scoliosis', 'spinal_stenosis', 'disc_protrusion',
                                        'disc_herniation', 'clinic_diagn_0', 'clinic_diagn_1', 'clinic_diagn_2', 
                                        'pharm_treat_analg', 'pharm_treat_NSAIDS', 'pharm_treat_steroids',
                                        'pharm_treat_musc_relax', 'pharm_treat_opioids',
                                        'pharm_treat_other', 'non_pharma_treat', 'NRT']
        else:
            self.categorical_features = ['sex', 'employ_status', 'time_first_episod_cat', 'chronicity',
                                        'diagn_RX', 'diagn_MRI', 'disc_degenerat', 'facet_joint_deg',
                                        'scoliosis', 'spinal_stenosis', 'disc_protrusion',
                                        'disc_herniation', 'clinic_diagn', 'pharm_treat_analg',
                                        'pharm_treat_NSAIDS', 'pharm_treat_steroids',
                                        'pharm_treat_musc_relax', 'pharm_treat_opioids',
                                        'pharm_treat_other', 'non_pharma_treat', 'NRT']
        
        super().__init__()
